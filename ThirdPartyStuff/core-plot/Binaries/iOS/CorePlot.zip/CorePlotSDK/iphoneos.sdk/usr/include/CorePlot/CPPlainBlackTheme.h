
#import <Foundation/Foundation.h>
#import "CPXYTheme.h"

@interface CPPlainBlackTheme : CPXYTheme {

}

@end
