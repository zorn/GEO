
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

void CPPushCGContext(CGContextRef context);
void CPPopCGContext(void);

CGContextRef CPGetCurrentContext(void);
