#import <Foundation/Foundation.h>

/**	@category NSNumber(CPExtensions)
 *	@brief Core Plot extensions to NSNumber.
 **/
@interface NSNumber(CPExtensions)

-(NSDecimalNumber *)decimalNumber;

@end

